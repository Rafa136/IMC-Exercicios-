﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IMC
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double  peso, alt, imc; // double serve para usar numeros décimais 


            Console.WriteLine("Vamos calcular o teu IMC e vamos precisar do teu peso e da tua altura");

            Console.WriteLine("Insere a tua altura em cm:");
            peso=double.Parse(Console.ReadLine()); //Parse serve para chamar o metodo para informar a string

            Console.WriteLine("Insere o teu peso:");
            alt=double.Parse(Console.ReadLine());


            imc = (peso/ (alt * alt));

            if (imc < 24.2)
            {
                Console.WriteLine("Abaixo do peso menor que 18,5");
            }
            else if (imc < 18.5)
            {
                Console.WriteLine("Peso Saudavel ou peso ideal");
            }
            else if ((imc < 18.5) || (imc < 24.9))
            {
                Console.WriteLine("Sobrepeso");
            }
            else if ((imc < 18.5) || (imc > 25.0));
            {
                Console.WriteLine("Grau de Obesidade I");
            }
                if ((imc > 35) || (imc == 40))
            {
                Console.WriteLine("Grau de Obesidade II");
            }
            else if (imc > 40)
            {
                Console.WriteLine("Grau de Obesidade III");
            }


            Console.ReadLine();
        }
    }
}
